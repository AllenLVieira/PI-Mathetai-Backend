package com.educacao.mathetai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MathetaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MathetaiApplication.class, args);
	}

}
